LUX 26 ANDROID APK — PHONE-ONLY BUILD

What this does
- Creates a small Android WebView app that opens the existing live LUX 26 website:
  https://ebillcheck.github.io/YourBill/
- Does not copy or modify index.html or Firebase data.
- Keeps the website's Firebase email/password authentication and billing logic on the hosted page.
- Provides a native file picker for JSON backup import.
- Intercepts Blob-based downloads (including html2pdf.js output and JSON export) and saves them under Downloads/LUX26.
- Builds a DEBUG APK in GitHub Actions and uploads it as an Actions artifact.

Repository layout to upload
Upload the CONTENTS of the supplied LUX26_Android_APK folder into the ROOT of eBillcheck/YourBill:
  .github/workflows/build-apk.yml
  android/settings.gradle
  android/build.gradle
  android/gradle.properties
  android/app/build.gradle
  android/app/src/main/AndroidManifest.xml
  android/app/src/main/java/com/ebillcheck/lux26/MainActivity.java
  android/app/src/main/res/drawable/ic_lux26.xml

Do not upload this folder as a nested LUX26_Android_APK directory. The .github folder must merge with any existing .github folder; do not replace or delete existing workflows.

Phone steps
1. Open https://github.com/eBillcheck/YourBill in Chrome and sign in.
2. At repository root choose Add file > Upload files.
3. Upload the listed files preserving the exact folder paths. If mobile upload cannot create nested folders, create folders first using Add file > Create new file and include the path in the filename; then add the contents. Keep hidden .github visible; GitHub accepts the leading dot path.
4. Commit to main.
5. Open repository > Actions > Build LUX 26 APK.
6. Open the latest run. Wait for the build to complete successfully.
7. Scroll to Artifacts and download LUX26-debug-APK. Extract the ZIP; it contains app-debug.apk.
8. Tap the APK on the phone and install. Android may ask you to allow installs from the browser/file manager you used. Only install this APK from your own repository workflow run.

Important limitations / checks
- This is a DEBUG APK for personal testing/sideloading, not a Play Store release. A release APK/AAB should be separately signed and kept secure.
- The app requires internet because it loads the GitHub Pages website and Firebase services online.
- PDF/blob download interception is implemented for the website's anchor-download flow. Must test monthly/lifetime PDFs and JSON backup on the actual phone; very large PDFs may require memory testing.
- JSON import uses Android's document picker through WebView file chooser support.
- The app loads only HTTPS pages from ebillcheck.github.io internally. Links to other hosts open outside the app.
- Firebase Realtime Database public read rules remain public as currently configured. This APK does not change database permissions.
- No Firebase web config, passwords, tokens, or signing keys are embedded in this project.
