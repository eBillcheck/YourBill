package com.ebillcheck.lux26;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;
import android.util.Base64;
import android.util.Log;

import java.io.OutputStream;
import java.io.IOException;
import java.net.URLDecoder;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final String TAG = "LUX26";
    private static final String START_URL = "https://ebillcheck.github.io/YourBill/";
    private static final String ALLOWED_HOST = "ebillcheck.github.io";
    private static final int FILE_CHOOSER_REQUEST = 4201;

    private WebView webView;
    private ProgressBar progressBar;
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(23, 25, 29));
        getWindow().setNavigationBarColor(Color.rgb(23, 25, 29));

        FrameLayout root = new FrameLayout(this);
        webView = new WebView(this);
        progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(230, 91, 47)));
        progressBar.setBackgroundColor(Color.TRANSPARENT);
        FrameLayout.LayoutParams barParams = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, dp(3));
        root.addView(webView, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
        root.addView(progressBar, barParams);
        setContentView(root);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setLoadsImagesAutomatically(true);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        settings.setSupportMultipleWindows(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setDefaultTextEncodingName("UTF-8");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);
        webView.addJavascriptInterface(new LuxBridge(), "LUX26Native");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if ("https".equalsIgnoreCase(uri.getScheme()) && ALLOWED_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                openExternal(uri);
                return true;
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                installDownloadBridge();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                super.onReceivedError(view, request, error);
                if (request.isForMainFrame()) {
                    Toast.makeText(MainActivity.this, "Unable to load LUX 26. Check your internet connection.", Toast.LENGTH_LONG).show();
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progressBar.setProgress(newProgress);
                progressBar.setVisibility(newProgress >= 100 ? android.view.View.GONE : android.view.View.VISIBLE);
            }

            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("*/*");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Select backup file"), FILE_CHOOSER_REQUEST);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker is available.", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        if (savedInstanceState != null) {
            webView.restoreState(savedInstanceState);
        } else {
            webView.loadUrl(START_URL);
        }
    }

    private void installDownloadBridge() {
        String js = "(function(){try{" +
                "if(window.__lux26DownloadBridgeInstalled)return;window.__lux26DownloadBridgeInstalled=true;" +
                "const nativeCreate=URL.createObjectURL.bind(URL);const blobMap=new Map();" +
                "URL.createObjectURL=function(blob){const u=nativeCreate(blob);if(blob instanceof Blob)blobMap.set(u,blob);return u;};" +
                "const originalClick=HTMLAnchorElement.prototype.click;" +
                "HTMLAnchorElement.prototype.click=function(){const href=this.href||'';" +
                "if(this.hasAttribute('download')&&href.startsWith('blob:')&&blobMap.has(href)&&window.LUX26Native){" +
                "const b=blobMap.get(href);const name=this.getAttribute('download')||'LUX26-download';" +
                "const reader=new FileReader();reader.onloadend=function(){const result=String(reader.result||'');const i=result.indexOf(',');if(i>=0)window.LUX26Native.saveBase64File(name,result.substring(i+1),b.type||'application/octet-stream');};" +
                "reader.readAsDataURL(b);return;}return originalClick.call(this);};" +
                "}catch(e){console.error('LUX26 download bridge error',e);}})();";
        webView.evaluateJavascript(js, null);
    }

    private void openExternal(Uri uri) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, uri));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "No app can open this link.", Toast.LENGTH_SHORT).show();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && filePathCallback != null) {
            Uri[] results = (resultCode == RESULT_OK && data != null && data.getData() != null)
                    ? new Uri[]{data.getData()} : null;
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) webView.saveState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) filePathCallback.onReceiveValue(null);
        if (webView != null) {
            webView.removeJavascriptInterface("LUX26Native");
            webView.destroy();
        }
        super.onDestroy();
    }

    private class LuxBridge {
        @JavascriptInterface
        public void saveBase64File(String rawName, String base64, String mimeType) {
            runOnUiThread(() -> saveFile(rawName, base64, mimeType));
        }
    }

    private void saveFile(String rawName, String base64, String mimeType) {
        String safeName = rawName == null ? "LUX26-download" : rawName.replaceAll("[^A-Za-z0-9._-]", "_");
        if (safeName.isEmpty()) safeName = "LUX26-download";
        try {
            byte[] bytes = Base64.decode(base64, Base64.DEFAULT);
            String type = (mimeType == null || mimeType.isEmpty()) ? "application/octet-stream" : mimeType;
            ContentValues values = new ContentValues();
            values.put(MediaStore.MediaColumns.DISPLAY_NAME, safeName);
            values.put(MediaStore.MediaColumns.MIME_TYPE, type);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/LUX26");
                values.put(MediaStore.MediaColumns.IS_PENDING, 1);
            }
            Uri collection = Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
                    ? MediaStore.Downloads.EXTERNAL_CONTENT_URI
                    : MediaStore.Files.getContentUri("external");
            Uri item = getContentResolver().insert(collection, values);
            if (item == null) throw new IOException("Unable to create download file");
            try (OutputStream out = getContentResolver().openOutputStream(item)) {
                if (out == null) throw new IOException("Unable to open download file");
                out.write(bytes);
                out.flush();
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(item, ready, null, null);
            }
            Toast.makeText(this, "Saved to Downloads/LUX26/" + safeName, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Log.e(TAG, "File save failed", e);
            Toast.makeText(this, "Could not save file: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
